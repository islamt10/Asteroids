import pygame
import random
import math
import asyncio
async def main():
    pygame.init()

    WIDTH, HEIGHT = 800, 600
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Asteroids")
    clock = pygame.time.Clock()

    ship_image = pygame.image.load("assets/Ship.png").convert_alpha()
    ship_image = pygame.transform.scale(ship_image,(60,60))
    MISSILE_SPEED = 7

    class Circle:
        def __init__(self, pos, direction, radius, color):
            self.pos = pos
            self.direction = direction
            self.radius = radius
            self.color = color

        def move(self):
            self.pos += self.direction

            if self.pos.x < -self.radius:
                self.pos.x = WIDTH + self.radius
            elif self.pos.x > WIDTH + self.radius:
                self.pos.x = -self.radius

            if self.pos.y < -self.radius:
                self.pos.y = HEIGHT + self.radius
            elif self.pos.y > HEIGHT + self.radius:
                self.pos.y = -self.radius

        def draw(self):
            pygame.draw.circle(screen, self.color, (self.pos.x, self.pos.y), self.radius)

    class Missile:
        def __init__(self, direction, pos):
            self.pos = pos
            self.direction = direction
            self.radius = 2
            self.color = (255,255,255)

        def move(self):
            self.pos +=self.direction

        def draw(self):
            pygame.draw.circle(screen, self.color, (self.pos.x, self.pos.y), self.radius)

    class Ship:
        def __init__(self):
            self.position = pygame.Vector2(WIDTH/2, HEIGHT/2)
            self.direction = pygame.Vector2(1,0)
            self.velocity = pygame.Vector2(0,0)
            self.VELOCITYMAX = 10
            self.angle = 0
            self.rotspeed = 3
            self.thrust = 0.15
            self.drag = .99
            self.acceleration =  self.direction * self.thrust
        def move(self):
            self.direction = pygame.Vector2(math.cos(math.radians(self.angle)), -math.sin(math.radians(self.angle)))
            self.velocity *= self.drag
            self.position += self.velocity
            if self.position.x < -30:
                self.position.x = WIDTH + 30
            elif self.position.x > WIDTH + 30:
                self.position.x = -30
            if self.position.y < -30:
                self.position.y = HEIGHT + 30
            elif self.position.y > HEIGHT + 30:
                self.position.y = -30
        def moveUp(self):
            self.acceleration =  self.direction * self.thrust
            self.velocity += self.acceleration
            if self.velocity.length() > self.VELOCITYMAX:
                self.velocity = self.velocity.normalize() * self.VELOCITYMAX

    class Enemy:
        def __init__(self, pos, Ship):
            self.detrange = 100
            self.angle = 0
            self.direction = pygame.Vector2(math.cos(math.radians(self.angle)), -math.sin(math.radians(self.angle)))
            self.pos = pos
            self.speed = 3
            self.playpos = Ship.position
            self.toplayer = self.playpos - self.pos
            self.dot = (self.toplayer.normalize()).dot(self.direction)
            self.distanceToPlayer = self.pos.distance_to(self.playpos)
            self.color = (255,255,255)
            self.state = "PATROL"
        def move(self):
            self.pos += self.direction * self.speed
            self.toplayer = self.playpos - self.pos
            self.dot = (self.toplayer.normalize()).dot(self.direction)
            self.distanceToPlayer = self.pos.distance_to(self.playpos)
            if self.dot > 0.7 and self.distanceToPlayer< self.detrange:
                self.state = "ATTACK"
                self.direction = self.toplayer.normalize()
                self.angle = math.degrees(math.atan2(-self.direction.y, self.direction.x))
            else: self.state = "PATROL"
            if self.state == "ATTACK":
                self.color = (255,0,0)
            else: self.color = (255,255,255)
            if self.pos.x < -30:
                self.pos.x = WIDTH + 30
            elif self.pos.x > WIDTH + 30:
                self.pos.x = -30
            if self.pos.y < -30:
                self.pos.y = HEIGHT + 30
            elif self.pos.y > HEIGHT + 30:
                self.pos.y = -30
        def draw(self):
            rotated_ship = pygame.transform.rotate(ship_image, enemy.angle)
            ship_rect = rotated_ship.get_rect(center=enemy.pos)
            screen.blit(rotated_ship, ship_rect)
            pygame.draw.circle(screen, self.color, self.pos, self.detrange, 1 )
            pygame.draw.line(screen, (255,0,0), enemy.pos,enemy.pos + enemy.direction * 100, 3)




            


        
    asteroids = []
    missiles= []

    for i in range(20):
        pos = pygame.math.Vector2((400 + random.randint(-300,300),300 + random.randint(-200,200)))
        direction = pygame.math.Vector2(random.randint(-2, 2),random.randint(-2, 2))
        radiues = random.randint(5,30)
        color = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
        asteroids.append(Circle(pos,direction,radiues, color))
    ship = Ship()
    enemy = Enemy(pygame.Vector2(0, HEIGHT/2), ship)
    BACKGROUND = (30, 30, 40)

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                direction1 = pygame.Vector2(
                    math.cos(math.radians(ship.angle)),
                    -math.sin(math.radians(ship.angle))
                )
                velocity = direction1 * MISSILE_SPEED
                missile = Missile(velocity, ship.position.copy())
                missiles.append(missile)


        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            ship.angle += ship.rotspeed

        if keys[pygame.K_RIGHT]:
            ship.angle -= ship.rotspeed
        back = pygame.Vector2(0,0)
        if keys[pygame.K_UP]:
            ship.moveUp()
            back = ship.position - ship.direction * 18
        ship.move()


        for ast in asteroids:
            ast.move()
        for missile in missiles:
            missile.move()
            for ast in asteroids:
                distance = math.sqrt((ast.pos.x - missile.pos.x) ** 2 + (ast.pos.y - missile.pos.y) ** 2)
                if distance < ast.radius + missile.radius:
                    asteroids.remove(ast)
                    missiles.remove(missile)
                    break
        
        for i in range(len(asteroids)):
                for j in range(i + 1, len(asteroids)):

                    c1 = asteroids[i]
                    c2 = asteroids[j]

                    distance = math.sqrt(
                        (c1.pos.x - c2.pos.x) ** 2 +
                        (c1.pos.y - c2.pos.y) ** 2
                    )

                    if distance <= c1.radius + c2.radius:
                        if distance > 0:
                            normal = (c2.pos - c1.pos).normalize()
                            relative_velocity = c1.direction - c2.direction

                            normal_speed = relative_velocity.dot(normal)
                            if normal_speed > 0:
                                mass1 = c1.radius
                                mass2 = c2.radius
                                impulse = (2 * normal_speed) / (mass1 + mass2)
                                c1.direction -= normal * (impulse * mass2)
                                c2.direction += normal * (impulse * mass1)



        screen.fill((20, 24, 40))
        pygame.draw.circle(
            screen,
            (255, 255, 0),
            back,
            5
        )
        for circle in asteroids:
            circle.draw()

        for missile in missiles:
            missile.draw()
        enemy.move()
        enemy.draw()
        rotated_ship = pygame.transform.rotate(ship_image, ship.angle)
        ship_rect = rotated_ship.get_rect(center=ship.position)
        screen.blit(rotated_ship, ship_rect)
        
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit
asyncio.run(main())